import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.imageio.ImageIO;

import java.awt.Font;
import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.awt.EventQueue;

public class TrackerApp extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JLabel lblAppTracker = new JLabel("App Tracker 1.0");
	private JLabel lblByAlexZaharia = new JLabel("by Alex Zaharia");
	private static Process process;
	private static String taskList = "";

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TrackerApp frame = new TrackerApp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TrackerApp() throws IOException {
        URL url16 = new URL("https://www.onlinecmag.com/wp-content/uploads/2014/12/fully-improving-the-windows-task-manager.png");
        URL url32 = new URL("https://www.onlinecmag.com/wp-content/uploads/2014/12/fully-improving-the-windows-task-manager.png");

        final List<Image> icons = new ArrayList<Image>();
        icons.add(ImageIO.read(url16));
        icons.add(ImageIO.read(url32));
        setTitle("App Tracker 1.0 by Alex Zaharia");
		setIconImages(icons);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 529, 150);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblAppTracker.setFont(new Font("Kristen ITC", Font.PLAIN, 30));
		lblAppTracker.setBounds(135, 11, 264, 63);
		contentPane.add(lblAppTracker);
		
		lblByAlexZaharia.setFont(new Font("Kristen ITC", Font.PLAIN, 12));
		lblByAlexZaharia.setBounds(208, 47, 264, 63);
		contentPane.add(lblByAlexZaharia);
	}
	
	public static String getTasks() throws IOException, InterruptedException {
		process = new ProcessBuilder("powershell", " gps | ? {$_.mainwindowhandle -ne 0} | select ProcessName | ft -hide").start();
		new Thread(() -> {
		    @SuppressWarnings("resource")
			Scanner sc = new Scanner(process.getInputStream());
		    if (sc.hasNextLine()) {
		    	sc.nextLine();
		    }
		    while (sc.hasNextLine()) {
		       String str = sc.nextLine();
			   taskList += str + "\n";
		    }
		}).start();
		process.waitFor();
		return taskList;
	}
}