import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread{
    private ServerSocket serverSocket;
    private int portNum;
    private boolean isRunning = false;
    private static TrackerApp frame;

    public Server(int portNum){
        this.portNum = portNum;
    }

    public void startServer(){
        try{
            serverSocket = new ServerSocket(portNum);
            this.start();
        }
        catch (IOException exception){
            exception.printStackTrace();
        }
    }

    public void stopServer(){
        isRunning = false;
        this.interrupt();
    }

    @Override
    public void run(){
        isRunning = true;
        while(isRunning){
            try{
                System.out.println("Listening for a connection");
                Socket socket = serverSocket.accept();
                RequestHandler rH = new RequestHandler( socket );
                rH.start();
            }
            catch (IOException exception){
                exception.printStackTrace();
            }
        }
    }

    public static void main(String [] args){
    	EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new TrackerApp();
					frame.setVisible(true);
				} 
				catch (Exception exception) {
					exception.printStackTrace();
				}
			}
		});
        int portNum = 1234;
        System.out.println("Server is starting on portNum " + portNum);
        Server server = new Server(portNum);
        server.startServer();
        try{
            Thread.sleep(360*1000);
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
        server.stopServer();
    }
}

class RequestHandler extends Thread{
    private Socket socket;
    RequestHandler(Socket socket){
        this.socket = socket;
    }

    public void run(){
        try{
            System.out.println("Connected");
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream());
            String tasks = TrackerApp.getTasks();
            out.println(tasks);
            out.flush();
            String line = in.readLine();
            while(line != null && line.length() >= 1){
                out.flush();
                line = in.readLine();
            }
            in.close();
            out.close();
            socket.close();
            System.out.println("Lost Connection");
            System.out.flush();
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
    }
}