import java.awt.EventQueue;

public class Client{
	
    public static void main( String[] args ) {
    	EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminApp frame = new AdminApp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
    }
}