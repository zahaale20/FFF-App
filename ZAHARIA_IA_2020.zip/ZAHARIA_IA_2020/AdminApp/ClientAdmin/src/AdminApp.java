import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JToggleButton;
import javax.swing.Timer;
import javax.swing.JSlider;
import javax.swing.JTextField;

public class AdminApp extends JFrame {

	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JLabel lblAppTracker = new JLabel("App Tracker 1.0");
	private JButton btnSendReport = new JButton("Send Report");
	private JToggleButton tglbtnEnableAutomatedReports = new JToggleButton("Enable Automated Reports");
	private JSlider slider = new JSlider();
	private JLabel lblTimeInterval = new JLabel("Time Interval: 30 minutes");
	public static JTextField textField;
	private JLabel lblNextReport = new JLabel("Next Report: " + calculateNextReportTime(0, 30));
	private JLabel lblAdminEmailAddress = new JLabel("Admin Email Address:");
	private JLabel lblerrorInputValid = new JLabel("*Error: Input Valid Email Address");
	private JLabel lblByAlexZaharia = new JLabel("by Alex Zaharia");

	public AdminApp() throws IOException {
        URL url16 = new URL("https://www.onlinecmag.com/wp-content/uploads/2014/12/fully-improving-the-windows-task-manager.png");
        URL url32 = new URL("https://www.onlinecmag.com/wp-content/uploads/2014/12/fully-improving-the-windows-task-manager.png");

        final List<Image> icons = new ArrayList<Image>();
        icons.add(ImageIO.read(url16));
        icons.add(ImageIO.read(url32));
        setTitle("App Tracker 1.0 by Alex Zaharia");
		setIconImages(icons);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 529, 325);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblAppTracker.setFont(new Font("Kristen ITC", Font.PLAIN, 30));
		lblAppTracker.setBounds(135, 11, 264, 63);
		contentPane.add(lblAppTracker);
		
		btnSendReport.setBackground(Color.LIGHT_GRAY);
		btnSendReport.setFont(new Font("Candara", Font.PLAIN, 20));
		btnSendReport.setBounds(38, 120, 149, 48);
		btnSendReport.addActionListener(new SendReport());
		contentPane.add(btnSendReport);
		
		tglbtnEnableAutomatedReports.setFont(new Font("Candara", Font.PLAIN, 15));
		tglbtnEnableAutomatedReports.setBackground(Color.LIGHT_GRAY);
		tglbtnEnableAutomatedReports.setBounds(251, 121, 221, 48);
		tglbtnEnableAutomatedReports.addActionListener(new AutomatedReports());
		tglbtnEnableAutomatedReports.addItemListener(new SendAutomatedReport());
		contentPane.add(tglbtnEnableAutomatedReports);
		
		slider.setSnapToTicks(true);
		slider.setForeground(Color.LIGHT_GRAY);
		slider.setValue(30);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setMaximum(360);
		slider.setMinimum(30);
		slider.setBounds(251, 187, 200, 24);
		slider.addChangeListener(new Slider());
		slider.setEnabled(false);
		contentPane.add(slider);
		
		lblTimeInterval.setFont(new Font("Candara", Font.PLAIN, 15));
		lblTimeInterval.setBounds(251, 208, 256, 24);
		lblTimeInterval.setEnabled(false);
		contentPane.add(lblTimeInterval);
		
		textField = new JTextField();
		textField.setBounds(38, 206, 171, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		lblAdminEmailAddress.setFont(new Font("Candara", Font.PLAIN, 11));
		lblAdminEmailAddress.setBounds(38, 179, 171, 30);
		contentPane.add(lblAdminEmailAddress);
		
		lblNextReport.setFont(new Font("Candara", Font.PLAIN, 15));
		lblNextReport.setBounds(251, 236, 256, 24);
		lblNextReport.setEnabled(false);
		contentPane.add(lblNextReport);
		
		lblerrorInputValid.setForeground(Color.RED);
		lblerrorInputValid.setFont(new Font("Candara", Font.PLAIN, 11));
		lblerrorInputValid.setBounds(38, 230, 171, 30);
		lblerrorInputValid.setVisible(false);
		contentPane.add(lblerrorInputValid);
		
		lblByAlexZaharia.setFont(new Font("Kristen ITC", Font.PLAIN, 12));
		lblByAlexZaharia.setBounds(208, 47, 264, 63);
		contentPane.add(lblByAlexZaharia);
	}
	class SendAutomatedReport implements ItemListener {
		public void itemStateChanged (ItemEvent e) {
			JToggleButton button = (JToggleButton) e.getSource();
			if(button.isEnabled()) {
				 EventQueue.invokeLater(new Runnable() {
			            @Override
			            public void run() {
			                ActionListener actionListener = new ActionListener() {

			                    public void actionPerformed(ActionEvent actionEvent) {
			                        SendReport report = new SendReport();
			                        report.generateAndSendReport();
			                    }
			                };
			                Timer timer = new Timer(/*slider.getValue()*60*1000*/5000, actionListener);
			                timer.start();
			            }
			        });				
			}
		}
	}
	
	class SendReport implements ActionListener {
		public void generateAndSendReport() {
			String server = "DESKTOP-L2ERQO1";
			String emailMessage = "Hi,\nHere is the report with the active applications running on " + server +":\n\n";
	        System.out.println( "Loading task list from " + server );
	        try{
	        	int port = 1234;
	            Socket socket = new Socket(server, port);
	            PrintStream out = new PrintStream( socket.getOutputStream() );
	            BufferedReader in = new BufferedReader( new InputStreamReader( socket.getInputStream() ) );
	            String str = in.readLine();
	            ArrayList<String> list = new ArrayList<>();
	            while(str != null && !list.contains(str)) {
	            	if(str.contains("SystemSettings") || str.contains("ApplicationFrameHost") || str.contains("HxOutlook") || str.contains("javaw") || str.contains("McUICnt") || str.contains("Time") || str.contains("WindowsInternal.ComposableShell.Experiences.TextInput.InputApp") ||str.contains("WWAHost") || str.contains("WindowsInternal.C...")) {
	            	}
	            	else {
	            		str = str.replace(" ","");
	        			System.out.println(str);
	            		emailMessage += "\t" + str + "\n";
	        			list.add(str);
	            	}
	            	str = in.readLine();
	            }
	            in.close();
	            out.close();
	            socket.close();
	        }
	        catch( Exception e1 ){
	            e1.printStackTrace();
	        }
	        emailMessage += "If you have any feedback regarding this application, please reply to this email.\n \nThanks,\nAlex Zaharia\nSkyline High School";
	        emailMessage = "Monkey Shit";
			SendEmail.sendEmail(emailMessage, textField.getText());
			lblerrorInputValid.setForeground(Color.GREEN);
			lblerrorInputValid.setText("*Report has been emailed.");
			lblerrorInputValid.setVisible(true);
		}
		
		public void actionPerformed (ActionEvent e) {
			generateAndSendReport();
		}
	}
	
	class Slider implements ChangeListener {
	    public void stateChanged(ChangeEvent e) {
	        JSlider source = (JSlider) e.getSource();
	        int time = source.getValue();
	        int time1 = time % 60;
	        time /= 60;
	        if (time < 1) {
	        	lblTimeInterval.setText("Time Interval: " + time1 + " minutes");
	        	lblNextReport.setText("Next Report: " + calculateNextReportTime(time, time1));
	        }
	        else if(time1 == 0) {
	        	lblTimeInterval.setText("Time Interval: " + time + " hours ");
	        	lblNextReport.setText("Next Report: " + calculateNextReportTime(time, time1));
	        }
	        else {
	        	lblTimeInterval.setText("Time Interval: " + time + " hours " + time1 + " minutes");
	        	lblNextReport.setText("Next Report: " + calculateNextReportTime(time, time1));
	        }
	    }
	}
	
	class AutomatedReports implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			JToggleButton button = (JToggleButton) e.getSource();
			if(isInvalid()) {
				lblerrorInputValid.setForeground(Color.RED);
				lblerrorInputValid.setText("*Error: Input Valid Email Address");
				lblerrorInputValid.setVisible(true);
			}
			else {
				if(button.getText().equals("Enable Automated Reports")) {
					button.setText("Disable Automated Reports");
					slider.setEnabled(true);
					lblTimeInterval.setEnabled(true);
					lblNextReport.setEnabled(true);
				}
				else {
					button.setText("Enable Automated Reports");
					slider.setEnabled(false);
					lblTimeInterval.setEnabled(false);
					lblNextReport.setEnabled(false);
				}
			}
		}
	}
	
	public static String calculateNextReportTime(int hours, int minutes) {
		int hour = java.time.LocalDateTime.now().getHour();
		int minute = java.time.LocalDateTime.now().getMinute();
		String ampm = null;
		String str = null;
		
		hour += hours;
		minute += minutes;
		
		if(minute > 60) {
			hour++;
			minute -= 60;
		}
		if(hour < 12) {
			ampm = "am";
		}
		if(hour > 12) {
			hour -= 12;
			ampm = "pm";
		}
		if(hour > 12) {
			hour -= 12;
			ampm = "am";
		}
		if(minute < 10) {
			str = hour + ":0" + minute + " " + ampm;	
		}
		else {
			str = hour + ":" + minute + " " + ampm;	
		}
		return str;
	}
	
	public static Boolean isInvalid() {
		if(textField.getText().contentEquals("")) {
			return true;
		}
		else if(!textField.getText().contains("@")|| !textField.getText().contains(".")) {
			return true;
		}
		return false;
	}
}